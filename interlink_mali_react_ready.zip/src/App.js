
import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>Bienvenue sur InterLink Mali</h1>
      <p>Votre plateforme de mise en relation professionnelle au Mali.</p>
    </div>
  );
}

export default App;
